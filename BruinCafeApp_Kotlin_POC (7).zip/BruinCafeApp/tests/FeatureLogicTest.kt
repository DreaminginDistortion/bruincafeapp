// Plain-JVM tests for the café/holiday date rules, rewards math, and menu-store wiring.
// Compile each test file SEPARATELY (they share top-level helper names):
//   D=app/src/main/java/com/bruincafe/app/data
//   kotlinc $D/Models.kt $D/MockData.kt $D/MealScheduler.kt $D/MenuStore.kt $D/Rewards.kt $D/SpecialMenu.kt tests/FeatureLogicTest.kt -d out
//   java -cp "out:<kotlinc>/lib/kotlin-stdlib.jar" FeatureLogicTestKt
import com.bruincafe.app.data.*
import java.time.LocalDate
import java.time.LocalTime

var failures = 0
fun check(name: String, cond: Boolean) { println((if (cond) "PASS  " else "FAIL  ") + name); if (!cond) failures++ }
fun d(m: Int, day: Int) = LocalDate.of(2026, m, day)

fun main() {
    val sp = MockData.specialItems
    // ---- holiday menu: only inside configured dates ----
    fun names(loc: String, date: LocalDate) = SpecialMenu.activeHolidayItems(sp, loc, date).map { it.item.name }
    check("Sep 30: no holiday items (day before start)", names("hq", d(9, 30)).isEmpty())
    check("Oct 1: Fall Favorites starts (first day counts)", names("hq", d(10, 1)) == listOf("Pumpkin Spice Latte", "Caramel Apple Cider"))
    check("Oct 31: still active (last day counts)", names("hq", d(10, 31)).size == 2)
    check("Nov 1: none between holidays", names("hq", d(11, 1)).isEmpty())
    check("Nov 20: Thanksgiving items", names("hq", d(11, 20)) == listOf("Pumpkin Pie Slice", "Turkey & Cranberry Wrap"))
    check("Dec 24: Winter Holidays last day", names("hq", d(12, 24)).size == 2)
    check("Dec 25: nothing", names("hq", d(12, 25)).isEmpty())
    check("Tech Center Oct 15 has only its own holiday item", names("tech_center", d(10, 15)) == listOf("Pumpkin Spice Latte"))
    check("holiday items never leak into café list", SpecialMenu.cafeItems(sp, "hq").none { it.item.mealPeriod == "holiday" })
    check("HQ café list = 4 made-to-order items", SpecialMenu.cafeItems(sp, "hq").size == 4 && SpecialMenu.cafeItems(sp, "hq").all { it.madeToOrder })
    check("Tech Center café list = 3 items", SpecialMenu.cafeItems(sp, "tech_center").size == 3)
    check("next holiday after Nov 1 is Thanksgiving", SpecialMenu.nextHoliday(sp, "hq", d(11, 1))?.holidayName == "Thanksgiving")
    check("next holiday after Dec 25 = none", SpecialMenu.nextHoliday(sp, "hq", d(12, 25)) == null)
    check("category labels", sp.first { it.item.id == "hq-cafe-latte" }.item.categoryLabel == "Café" &&
        sp.first { it.item.id == "hq-hol-psl" }.item.categoryLabel == "Holiday")

    // ---- punch-card rewards ----
    fun order(vararg quantities: Int) = Order("test", 0L, "Headquarters",
        quantities.mapIndexed { i, q -> OrderLineRecord("Item $i", q) })
    check("no orders -> 0 punches, 10 to go", Rewards.status(emptyList()).let { it.totalPunches == 0 && it.punchesToNext == 10 && it.progress == 0f && it.rewardsAvailable == 0 })
    check("3 items = 3 punches", order(1, 2).punches == 3)
    check("4 orders of 3 items = 12 punches: 1 reward, 2 on card",
        Rewards.status(List(4) { order(3) }).let { it.totalPunches == 12 && it.rewardsEarned == 1 && it.punchesOnCard == 2 && it.punchesToNext == 8 })
    check("exactly 10 punches -> card resets to 0, reward available", Rewards.status(List(2) { order(5) }).let { it.rewardsEarned == 1 && it.punchesOnCard == 0 && it.rewardsAvailable == 1 && it.progress == 0f })
    check("5 punches = half the card", Rewards.status(listOf(order(5))).progress == 0.5f)
    check("card resets but unredeemed rewards are kept (25 punches, 0 redeemed)", Rewards.status(List(5) { order(5) }).let { it.punchesOnCard == 5 && it.rewardsAvailable == 2 })
    check("redeeming one leaves the rest (25 punches, 1 redeemed)", Rewards.status(List(5) { order(5) }, redeemed = 1).let { it.rewardsAvailable == 1 && it.rewardsRedeemed == 1 && it.punchesOnCard == 5 })
    check("redeemed count can never exceed earned", Rewards.status(listOf(order(4)), redeemed = 3).let { it.rewardsAvailable == 0 && it.rewardsRedeemed == 0 })
    check("negative redeemed is treated as 0", Rewards.status(List(2) { order(5) }, redeemed = -2).rewardsAvailable == 1)

    // ---- store still behaves, with special items carried through ----
    val store = MenuStore.fromMock()
    check("MenuStore carries special items", store.special.size == sp.size)
    check("rows-built store accepts special items", MenuStore.fromRows(MockData.locations, MockData.mealPeriods, emptyList(), sp).special.size == sp.size)
    check("a11y defaults", AccessibilitySettings().let { it.textScale == 1.0f && !it.highContrast })
    check("3 text size options", AccessibilitySettings.textScaleOptions.size == 3)

    println(if (failures == 0) "\nALL FEATURE TESTS PASSED" else "\n$failures FAILED")
    if (failures > 0) System.exit(1)

    // ---- inventory covers regular + café + holiday items (linked to special_items) ----
    val inv = MockData.inventorySeed()
    check("every special item has an inventory row", MockData.specialItems.all { s -> inv.any { it.itemId == s.item.id } })
    check("inventory ids are unique", inv.map { it.itemId }.distinct().size == inv.size)
    check("kinds: 16 special rows (7 cafe + 9 holiday)",
        inv.count { it.itemKind == InventoryItem.KIND_CAFE } == 7 && inv.count { it.itemKind == InventoryItem.KIND_HOLIDAY } == 9)
    check("regular rows are 'meal'", inv.filter { it.itemKind == InventoryItem.KIND_MEAL }.size == inv.size - 16)
    check("kind matches special item type",
        MockData.specialItems.all { s ->
            inv.first { it.itemId == s.item.id }.itemKind == (if (s.item.mealPeriod == "holiday") InventoryItem.KIND_HOLIDAY else InventoryItem.KIND_CAFE)
        })
    check("sold-out café/holiday seeds", inv.first { it.itemId == "tc-cafe-chai" }.status == StockStatus.SOLD_OUT &&
        inv.first { it.itemId == "tc-hol-psl" }.status == StockStatus.SOLD_OUT)
    check("low-stock seeds", inv.first { it.itemId == "hq-cafe-hotchoc" }.status == StockStatus.LOW_STOCK)
    check("kind labels", InventoryItem.kindLabel("meal") == "Regular" && InventoryItem.kindLabel("cafe") == "Café" && InventoryItem.kindLabel("holiday") == "Holiday")

    // ---- real Nov 16-20 menus are what the app ships with ----
    val nov = MenuStore.fromMock()
    check("HQ Nov 17 lunch = Bacon & Cheese Loaded Fries", nov.itemsFor("hq", "2026-11-17", "lunch").map { it.name } == listOf("Bacon & Cheese Loaded Fries"))
    check("Tech Center Nov 18 lunch = Cuban-Style Panini", nov.itemsFor("tech_center", "2026-11-18", "lunch").map { it.name } == listOf("Cuban-Style Panini"))
    check("Tech Center has 5 real lunch items, no invented ones", MockData.weeklyMenuTechCenter.flatMap { it.items }.size == 5)
    check("default date is the nearest menu day (Nov 23 -> Nov 20)", nov.defaultDate("2026-11-23") == "2026-11-20")
    check("default date: Nov 19 has a menu", nov.defaultDate("2026-11-19") == "2026-11-19")
    check("every real lunch item has inventory", (MockData.weeklyMenuHq + MockData.weeklyMenuTechCenter).flatMap { it.items }
        .all { m -> MockData.inventorySeed().any { it.itemId == m.id } })
}
