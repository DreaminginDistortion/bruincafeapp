package com.bruincafe.app.data

/** One line of a past order, stored by name so history still reads correctly if the menu changes. */
data class OrderLineRecord(val name: String, val quantity: Int)

/** A completed (mock) order. Stored only on the customer's own device. */
data class Order(
    val id: String,
    val timeMillis: Long,
    val locationName: String,
    val lines: List<OrderLineRecord>
) {
    val itemCount: Int get() = lines.sumOf { it.quantity }
    /** Every item ordered earns one punch on the punch card. */
    val punches: Int get() = Rewards.punchesForItems(itemCount)
}

/**
 * The customer's punch card.
 *  - [punchesOnCard] is how many holes are punched on the CURRENT card (0..cardSize-1). It resets to 0
 *    every time the card fills up.
 *  - Each filled card earns one reward. [rewardsAvailable] = earned minus already redeemed, so a card
 *    can reset while the reward is still waiting to be redeemed.
 */
data class RewardsStatus(
    val totalPunches: Int,
    val punchesOnCard: Int,
    val punchesToNext: Int,
    val cardSize: Int,
    val rewardsEarned: Int,
    val rewardsRedeemed: Int,
    val rewardsAvailable: Int
) {
    val progress: Float get() = punchesOnCard.toFloat() / cardSize
}

/**
 * Punch-card rules. Punches are DERIVED from order history; the only extra thing stored is how many
 * rewards have been redeemed (see RewardsStore), so punches and history can never disagree.
 *
 *   1 punch per item ordered, 10 punches fills the card = 1 free item, then the card starts over.
 */
object Rewards {
    const val PUNCHES_PER_ITEM = 1
    const val PUNCHES_PER_CARD = 10

    fun punchesForItems(itemCount: Int): Int = itemCount.coerceAtLeast(0) * PUNCHES_PER_ITEM

    fun status(orders: List<Order>, redeemed: Int = 0): RewardsStatus {
        val total = orders.sumOf { it.punches }
        val earned = total / PUNCHES_PER_CARD
        val onCard = total % PUNCHES_PER_CARD
        val used = redeemed.coerceIn(0, earned)        // can never redeem more than were earned
        return RewardsStatus(
            totalPunches = total,
            punchesOnCard = onCard,
            punchesToNext = PUNCHES_PER_CARD - onCard,
            cardSize = PUNCHES_PER_CARD,
            rewardsEarned = earned,
            rewardsRedeemed = used,
            rewardsAvailable = earned - used
        )
    }
}

/** User-chosen accessibility options (on top of the phone's own system settings). */
data class AccessibilitySettings(
    val textScale: Float = 1.0f,       // multiplies the system font size
    val highContrast: Boolean = false
) {
    companion object {
        val textScaleOptions: List<Pair<String, Float>> = listOf(
            "Default" to 1.0f,
            "Large" to 1.3f,
            "Extra large" to 1.6f
        )
    }
}
