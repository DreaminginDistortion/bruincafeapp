package com.bruincafe.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.bruincafe.app.data.InventoryItem

/**
 * Screen S-09: Stock adjustment. Staff TYPE the number of units and tap Confirm:
 * Restock adds exactly that many to the available stock, Un-stock removes that many (never below 0).
 */
@Composable
fun RestockSimulationScreen(
    item: InventoryItem,
    currentQuantity: Int,
    onConfirmRestock: (Int) -> Unit,
    onConfirmUnstock: (Int) -> Unit,
    onBack: () -> Unit
) {
    var typed by remember { mutableStateOf("") }              // what the staff member typed
    var unstockMode by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    val verb = if (unstockMode) "Un-stock" else "Restock"

    val amount = typed.toIntOrNull()
    val error = when {
        typed.isEmpty() -> null                                          // nothing typed yet: no scolding
        amount == null || amount < 1 -> "Enter a whole number of 1 or more."
        unstockMode && amount > currentQuantity -> "Only $currentQuantity on hand - you can remove at most $currentQuantity."
        else -> null
    }
    val canConfirm = amount != null && amount >= 1 && error == null

    Scaffold(
        topBar = { TopAppBar(title = { ScreenTitle("Stock: ${item.itemName}") }, navigationIcon = { BackButton(onBack) }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                "${InventoryItem.kindLabel(item.itemKind)} item",
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                "$currentQuantity on hand",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }   // announces the new total after each change
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SelectableChip("Restock (add)", !unstockMode, { unstockMode = false; lastResult = null })
                SelectableChip("Un-stock (remove)", unstockMode, { unstockMode = true; lastResult = null })
            }
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = typed,
                onValueChange = { new ->
                    typed = new.filter { it.isDigit() }.take(5)      // digits only, up to 99,999
                    lastResult = null
                },
                label = { Text(if (unstockMode) "Number of units to remove" else "Number of units to add") },
                singleLine = true,
                isError = error != null,
                supportingText = { if (error != null) Text(error) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            if (canConfirm) {
                val delta = amount ?: 0
                val preview = if (unstockMode) currentQuantity - delta else currentQuantity + delta
                Text("New total will be $preview.", modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                enabled = canConfirm,
                onClick = {
                    val n = amount
                    if (n != null) {
                        if (unstockMode) onConfirmUnstock(n) else onConfirmRestock(n)
                        lastResult = if (unstockMode) "Removed $n." else "Added $n."
                        typed = ""                                        // ready for the next entry
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
            ) { Text("Confirm $verb") }
            lastResult?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .semantics { liveRegion = LiveRegionMode.Polite }
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Back to Inventory")
            }
        }
    }
}
