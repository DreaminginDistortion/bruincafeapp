package com.bruincafe.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bruincafe.app.data.Rewards
import com.bruincafe.app.data.RewardsStatus

/**
 * Screen S-01: Home = Rewards home.
 * Shows the customer's points and progress first, then the main places to go.
 * The whole screen scrolls, so it stays usable at "Extra large" text sizes.
 */
@Composable
fun HomeScreen(
    rewards: RewardsStatus,
    onOrder: () -> Unit,
    onCafeHoliday: () -> Unit,
    onOrderHistory: () -> Unit,
    onAccessibility: () -> Unit,
    onStaffLogin: () -> Unit,
    onRedeem: () -> Boolean
) {
    Scaffold(topBar = { TopAppBar(title = { BrandTitle("Bruin Café") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RewardsCard(rewards, onRedeem)

            Text(
                "Every item you order earns a punch. Fill all ${Rewards.PUNCHES_PER_CARD} punches to earn a free item - " +
                    "then your card starts over, and your reward waits for you until you redeem it.",
                style = MaterialTheme.typography.bodyMedium
            )

            Button(onClick = onOrder, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Order Now")
            }
            OutlinedButton(onClick = onCafeHoliday, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Café & Holiday Menu")
            }
            OutlinedButton(onClick = onOrderHistory, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Order History")
            }
            OutlinedButton(onClick = onAccessibility, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Accessibility Settings")
            }
            TextButton(onClick = onStaffLogin, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                Text("Staff Login")
            }
        }
    }
}

/** The punch card: a grid of holes, filled in as the customer orders. Resets after 10 but keeps unredeemed rewards. */
@Composable
private fun RewardsCard(rewards: RewardsStatus, onRedeem: () -> Boolean) {
    val scheme = MaterialTheme.colorScheme
    var showRedeemDialog by remember { mutableStateOf(false) }
    var justRedeemed by remember { mutableStateOf(false) }

    val rewardText = when (rewards.rewardsAvailable) {
        0 -> "No rewards to redeem yet."
        1 -> "1 free item ready to redeem!"
        else -> "${rewards.rewardsAvailable} free items ready to redeem!"
    }
    // One clear sentence for screen readers instead of ten separate circles.
    val spoken = "Bruin punch card. ${rewards.punchesOnCard} of ${rewards.cardSize} punches. " +
        "${rewards.punchesToNext} more for a free item. $rewardText"

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = scheme.primary, contentColor = scheme.onPrimary),
        border = contrastBorder()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Column(modifier = Modifier.semantics(mergeDescendants = true) { contentDescription = spoken }) {
                Text(
                    "Bruin Punch Card",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.semantics { heading() }
                )
                Text(
                    "${rewards.punchesOnCard} / ${rewards.cardSize} punches",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                // Two rows of five holes. Filled = punched (shows a check), empty = outline only.
                (0 until 2).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        (0 until rewards.cardSize / 2).forEach { col ->
                            val index = row * (rewards.cardSize / 2) + col
                            val punched = index < rewards.punchesOnCard
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (punched) scheme.onPrimary else Color.Transparent)
                                    .border(2.dp, scheme.onPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (punched) "✓" else "${index + 1}",
                                    color = if (punched) scheme.primary else scheme.onPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("${rewards.punchesToNext} more ${if (rewards.punchesToNext == 1) "punch" else "punches"} for a free item")
                Text(rewardText, fontWeight = FontWeight.SemiBold)
            }
            if (rewards.rewardsAvailable > 0) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { showRedeemDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = scheme.onPrimary, contentColor = scheme.primary),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
                ) { Text("Redeem free item") }
            }
            if (justRedeemed) {
                Text(
                    "Reward redeemed. Show this screen to the cashier.",
                    modifier = Modifier.padding(top = 8.dp).semantics { liveRegion = LiveRegionMode.Polite }
                )
            }
        }
    }

    if (showRedeemDialog) {
        AlertDialog(
            onDismissRequest = { showRedeemDialog = false },
            title = { Text("Redeem a free item?") },
            text = { Text("This uses 1 of your ${rewards.rewardsAvailable} rewards. Show the cashier this screen after you confirm.") },
            confirmButton = {
                TextButton(onClick = {
                    justRedeemed = onRedeem()
                    showRedeemDialog = false
                }) { Text("Redeem") }
            },
            dismissButton = { TextButton(onClick = { showRedeemDialog = false }) { Text("Cancel") } }
        )
    }
}
