package com.bruincafe.app.ui.theme

import androidx.compose.ui.graphics.Color

// SCHOOL COLORS -- sampled from the official Blue Ridge Community and Technical College logo:
// the blue "Blue" lettering and the red "Ridge" lettering. To re-brand the whole app, change only these values.
val SchoolNavy = Color(0xFF0F4B7D)      // primary blue: top bars, buttons, rewards card
val SchoolMaroon = Color(0xFF8C0C03)    // accent: banners, badges, small accent text
val SchoolTint = Color(0xFFE1EBF5)      // light blue tint behind cards
val SchoolMist = Color(0xFFECF2F8)      // panels / chips background
val SchoolSurface = Color(0xFFFAFBFE)   // screen background
val CafeInk = Color(0xFF1C1B1F)         // body text

// ACCESSIBILITY: every text/background pair below is checked by tests/contrast_check.py (WCAG AA).
// SchoolSilver is decoration only -- never use it for text.
val SchoolSilver = Color(0xFF8A93A8)

val CafeError = Color(0xFFB3261E)

// High-contrast mode (settings screen): black on white, very dark navy, heavy borders.
val HcBlack = Color(0xFF000000)
val HcWhite = Color(0xFFFFFFFF)
val HcNavy = Color(0xFF082A47)
val HcError = Color(0xFF8C0000)
