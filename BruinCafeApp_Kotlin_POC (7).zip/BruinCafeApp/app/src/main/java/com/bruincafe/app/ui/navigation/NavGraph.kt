package com.bruincafe.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.bruincafe.app.data.CafeRepository
import com.bruincafe.app.data.InventoryItem
import com.bruincafe.app.data.MenuItem
import com.bruincafe.app.ui.CafeViewModel
import com.bruincafe.app.ui.screens.AccessibilitySettingsScreen
import com.bruincafe.app.ui.screens.CafeHolidayScreen
import com.bruincafe.app.ui.screens.CartScreen
import com.bruincafe.app.ui.screens.CheckoutScreen
import com.bruincafe.app.ui.screens.HomeScreen
import com.bruincafe.app.ui.screens.InventoryDashboardScreen
import com.bruincafe.app.ui.screens.ItemDetailScreen
import com.bruincafe.app.ui.screens.LocationSelectScreen
import com.bruincafe.app.ui.screens.OrderHistoryScreen
import com.bruincafe.app.ui.screens.RestockSimulationScreen
import com.bruincafe.app.ui.screens.StaffLoginScreen
import com.bruincafe.app.ui.screens.WeeklyMenuScreen

/**
 * Screen route names -- mirror the Screen Inventory IDs in comments so the
 * document and the code never drift apart.
 */
private object Routes {
    const val HOME = "home"                       // S-01  Rewards home
    const val LOCATION = "location"               // S-02
    const val WEEKLY_MENU = "weekly_menu"         // S-03
    const val ITEM_DETAIL = "item_detail"         // S-04
    const val CART = "cart"                       // S-05
    const val CHECKOUT = "checkout"               // S-06
    const val STAFF_LOGIN = "staff_login"         // S-07
    const val INVENTORY = "inventory"             // S-08
    const val RESTOCK = "restock"                 // S-09
    const val ORDER_HISTORY = "order_history"     // S-10 (new)
    const val CAFE_HOLIDAY = "cafe_holiday"       // S-11 (new)
    const val ACCESSIBILITY = "accessibility"     // S-12 (new)
}

@Composable
fun BruinCafeNavGraph(viewModel: CafeViewModel) {
    val navController: NavHostController = rememberNavController()
    val uiState by viewModel.uiState.collectAsState()
    val inventoryVersion by viewModel.inventoryVersion.collectAsState()

    // Pure UI navigation state: which item the customer / staff member is looking at.
    var selectedItem by remember { mutableStateOf<MenuItem?>(null) }
    var selectedInventoryRow by remember { mutableStateOf<InventoryItem?>(null) }
    var staffLocationId by remember { mutableStateOf("hq") }
    var staffKind by remember { mutableStateOf(InventoryItem.KIND_MEAL) }

    val currentLocationId = uiState.selectedLocationId ?: uiState.locations.first().id
    // ---- Back-button fix (white screen bug) ----
    // Before: goBack = popBackStack(). Tapping Back twice quickly (or Back on the first screen) popped
    // the Home screen too, leaving an empty NavHost = a blank white screen.
    // Now: only pop when (a) there IS a screen to go back to and (b) the current screen has finished
    // its transition, so a double tap is ignored instead of popping two screens.
    val goBack: () -> Unit = {
        val canPop = navController.previousBackStackEntry != null &&
            navController.currentBackStackEntry?.lifecycle?.currentState == Lifecycle.State.RESUMED
        if (canPop) navController.popBackStack()
    }
    // Same idea for forward taps: a double tap on "Order Now" must not stack two copies of a screen.
    val go: (String) -> Unit = { route -> navController.navigate(route) { launchSingleTop = true } }

    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                rewards = uiState.rewards,
                onOrder = { go(Routes.LOCATION) },
                onCafeHoliday = {
                    viewModel.selectLocation(currentLocationId)
                    go(Routes.CAFE_HOLIDAY)
                },
                onOrderHistory = { go(Routes.ORDER_HISTORY) },
                onAccessibility = { go(Routes.ACCESSIBILITY) },
                onStaffLogin = { go(Routes.STAFF_LOGIN) },
                onRedeem = viewModel::redeemReward
            )
        }

        composable(Routes.LOCATION) {
            LocationSelectScreen(
                locations = uiState.locations,
                onLocationChosen = {
                    viewModel.selectLocation(it.id)
                    go(Routes.WEEKLY_MENU)
                },
                onBack = goBack
            )
        }

        composable(Routes.WEEKLY_MENU) {
            val location = uiState.locations.firstOrNull { it.id == currentLocationId } ?: uiState.locations.first()
            WeeklyMenuScreen(
                location = location,
                periods = uiState.mealPeriods,
                now = uiState.effectiveTime,
                simulatedTime = uiState.simulatedTime,
                onSimulatedTimeChange = viewModel::setSimulatedTime,
                simulatedDate = uiState.simulatedDate,
                onSimulatedDateChange = viewModel::setSimulatedDate,
                dataSource = uiState.dataSource,
                isLoading = uiState.isLoading,
                loadError = uiState.loadError,
                onRefresh = viewModel::refreshData,
                onItemClick = {
                    selectedItem = it
                    go(Routes.ITEM_DETAIL)
                },
                onViewCart = { go(Routes.CART) },
                cartCount = uiState.cart.sumOf { it.quantity },
                cartMessage = uiState.cartMessage,
                onCartMessageShown = viewModel::clearCartMessage,
                onBack = goBack
            )
        }

        composable(Routes.CAFE_HOLIDAY) {
            CafeHolidayScreen(
                locations = uiState.locations,
                selectedLocationId = currentLocationId,
                onLocationChange = viewModel::selectLocation,
                holidayDemoDate = uiState.holidayDemoDate,
                onHolidayDemoDateChange = viewModel::setHolidayDemoDate,
                onItemClick = {
                    selectedItem = it
                    go(Routes.ITEM_DETAIL)
                },
                onViewCart = { go(Routes.CART) },
                cartCount = uiState.cart.sumOf { it.quantity },
                cartMessage = uiState.cartMessage,
                onCartMessageShown = viewModel::clearCartMessage,
                onBack = goBack
            )
        }

        composable(Routes.ITEM_DETAIL) {
            val item = selectedItem
            if (item == null) {
                LaunchedEffect(Unit) { goBack() }          // nothing selected (e.g. process restored): leave instead of showing white
            } else {
                ItemDetailScreen(
                    item = item,
                    onAddToCart = {
                        viewModel.addToCart(it)
                        goBack()
                    },
                    onBack = goBack
                )
            }
        }

        composable(Routes.CART) {
            CartScreen(
                cart = uiState.cart,
                onRemove = viewModel::removeFromCart,
                onCheckout = { go(Routes.CHECKOUT) },
                onKeepBrowsing = goBack,
                cartMessage = uiState.cartMessage,
                onCartMessageShown = viewModel::clearCartMessage,
                onBack = goBack
            )
        }

        composable(Routes.CHECKOUT) {
            CheckoutScreen(
                cart = uiState.cart,
                confirmedOrder = uiState.confirmedOrder,
                orderError = uiState.lastOrderError,
                onPlaceOrder = viewModel::placeOrder,
                onNewOrder = {
                    viewModel.clearOrderConfirmation()
                    navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                },
                onViewHistory = {
                    navController.navigate(Routes.ORDER_HISTORY) { popUpTo(Routes.HOME) }
                    viewModel.clearOrderConfirmation()
                },
                onBack = goBack
            )
        }

        composable(Routes.ORDER_HISTORY) {
            OrderHistoryScreen(
                orders = uiState.orders,
                rewards = uiState.rewards,
                onReorder = { order -> if (viewModel.reorder(order)) go(Routes.CART) },
                onBack = goBack
            )
        }

        composable(Routes.ACCESSIBILITY) {
            AccessibilitySettingsScreen(
                settings = uiState.accessibility,
                onChange = viewModel::setAccessibility,
                onBack = goBack
            )
        }

        composable(Routes.STAFF_LOGIN) {
            StaffLoginScreen(
                onLogin = viewModel::staffLogin,
                onLoginSuccess = { go(Routes.INVENTORY) },
                onBack = goBack
            )
        }

        composable(Routes.INVENTORY) {
            // Reading inventoryVersion here forces recomposition after a restock.
            val refreshKey = inventoryVersion
            InventoryDashboardScreen(
                locations = uiState.locations,
                selectedLocationId = staffLocationId,
                onLocationChange = { staffLocationId = it },
                inventory = CafeRepository.inventoryFor(staffLocationId, staffKind),
                selectedKind = staffKind,
                onKindChange = { staffKind = it },
                onQuickAdjust = { row, delta ->
                    if (delta >= 0) viewModel.restock(row.itemId, delta) else viewModel.unstock(row.itemId, -delta)
                },
                onSelectItemToRestock = {
                    selectedInventoryRow = it
                    go(Routes.RESTOCK)
                },
                onLogout = {
                    viewModel.staffLogout()
                    navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                }
            )
        }

        composable(Routes.RESTOCK) {
            val row = selectedInventoryRow
            if (row == null) {
                LaunchedEffect(Unit) { goBack() }
            } else {
                val refreshKey = inventoryVersion
                RestockSimulationScreen(
                    item = row,
                    currentQuantity = CafeRepository.quantityOnHand(row.itemId),
                    onConfirmRestock = { qty -> viewModel.restock(row.itemId, qty) },
                    onConfirmUnstock = { qty -> viewModel.unstock(row.itemId, qty) },
                    onBack = goBack
                )
            }
        }
    }
}
